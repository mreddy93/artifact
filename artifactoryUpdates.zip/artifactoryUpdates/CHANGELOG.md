# JFrog Artifactory Chart Changelog
All changes to this chart will be documented in this file.

## [11.4.5] - Nov 9, 2020
* Updated Artifactory version to 7.10.6 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.10.6)

## [11.4.4] - Nov 2, 2020
* Add enablePathStyleAccess property for aws-s3-v3 binary provider template

## [11.4.3] - Nov 2, 2020
* Updated Artifactory version to 7.10.5 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.10.5)

## [11.4.2] - Oct 22, 2020
* Chown bug fix where Linux capability cannot chown all files causing log line warnings
* Fix Frontend timeout linting issue

## [11.4.1] - Oct 20, 2020
* Add flag to disable prepare-custom-persistent-volume init container

## [11.4.0] - Oct 19, 2020
* Updated Artifactory version to 7.10.2 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.10.2)

## [11.3.2] - Oct 15, 2020
* Add support to specify priorityClassName for nginx deployment

## [11.3.1] - Oct 9, 2020
* Add support for customInitContainersBegin

## [11.3.0] - Oct 7, 2020
* Updated Artifactory version to 7.9.1
* **Breaking change:** Fix `storageClass` to correct `storageClassName` in values.yaml

## [11.2.0] - Oct 5, 2020
* Expose Prometheus metrics via a ServiceMonitor
* Parse log files for metric data with Fluentd

## [11.1.0] - Sep 30, 2020
* Updated Artifactory version to 7.9.0 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.9)
* Added support for resources in init container

## [11.0.11] - Sep 25, 2020
* Update to use linux capability CAP_CHOWN instead of root base init container to avoid any use of root containers to pass Redhat security requirements

## [11.0.10] - Sep 28, 2020
* Setting chart coordinates in migitation yaml

## [11.0.9] - Sep 25, 2020
* Update filebeat version to `7.9.2`

## [11.0.8] - Sep 24, 2020
* Fixed broken issue - when setting `waitForDatabase: false` container startup still waits for DB

## [11.0.7] - Sep 22, 2020
* Readme updates

## [11.0.6] - Sep 22, 2020
* Fix lint issue in migitation yaml

## [11.0.5] - Sep 22, 2020
* Fix broken migitation yaml

## [11.0.4] - Sep 21, 2020
* Added mitigation yaml for Artifactory - [More info](https://github.com/jfrog/chartcenter/blob/master/docs/securitymitigationspec.md)

## [11.0.3] - Sep 17, 2020
* Added configurable session(UI) timeout in frontend microservice

## [11.0.2] - Sep 17, 2020
* Added proper required text to be shown while postgres upgrades

## [11.0.1] - Sep 14, 2020
* Updated Artifactory version to 7.7.8 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.7.8)

## [11.0.0] - Sep 2, 2020
* **Breaking change:** Changed `imagePullSecrets`values from string to list.
* **Breaking change:** Added `image.registry` and changed `image.version` to `image.tag` for docker images
* Added support for global values
* Updated maintainers in chart.yaml
* Update postgresql tag version to `12.3.0-debian-10-r71`
* Update postgresql chart version to `9.3.4` in requirements.yaml - [9.x Upgrade Notes](https://github.com/bitnami/charts/tree/master/bitnami/postgresql#900)
* **IMPORTANT**
* If this is a new deployment or you already use an external database (`postgresql.enabled=false`), these changes **do not affect you**!
* If this is an upgrade and you are using the default PostgreSQL (`postgresql.enabled=true`), you need to pass previous 9.x/10.x's postgresql.image.tag and databaseUpgradeReady=true

## [10.1.0] - Aug 13, 2020
* Updated Artifactory version to 7.7.3 - [Release Notes](https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.7)

## [10.0.15] - Aug 10, 2020
* Added enableSignedUrlRedirect for persistent storage type aws-s3-v3.

## [10.0.14] - Jul 31, 2020
* Update the README section on Nginx SSL termination to reflect the actual YAML structure.

## [10.0.13] - Jul 30, 2020
* Added condition to disable the migration scripts.

## [10.0.12] - Jul 28, 2020
* Document Artifactory node affinity.

## [10.0.11] - Jul 28, 2020
* Added maxConnections for persistent storage type aws-s3-v3.

## [10.0.10] - Jul 28, 2020
* Bugfix / support for userPluginSecrets with Artifactory 7

## [10.0.9] - Jul 27, 2020
* Add tpl to external database secrets
* Modified `scheme`  to `artifactory.scheme`

## [10.0.8] - Jul 23, 2020
* Added condition to disable the migration init container.

## [10.0.7] - Jul 21, 2020
* Updated Artifactory Chart to add node and primary labels to pods and service objects.

## [10.0.6] - Jul 20, 2020
* Support custom CA and certificates

## [10.0.5] - Jul 13, 2020
* Updated Artifactory version to 7.6.3 - https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.6.3
* Fixed Mysql database jar path in `preStartCommand` in README

## [10.0.4] - Jul 10, 2020
* Move some postgresql values to where they should be according to the subchart

## [10.0.3] - Jul 8, 2020
* Set Artifactory access client connections to the same value as the access threads

## [10.0.2] - Jul 6, 2020
* Updated Artifactory version to 7.6.2
* **IMPORTANT**
* Added ChartCenter Helm repository in README

## [10.0.1] - Jul 01, 2020
* Add dedicated ingress object for Replicator service when enabled

## [10.0.0] - Jun 30, 2020
* Update postgresql tag version to `10.13.0-debian-10-r38`
* Update alpine tag version to `3.12`
* Update busybox tag version to `1.31.1`
* **IMPORTANT**
* If this is a new deployment or you already use an external database (`postgresql.enabled=false`), these changes **do not affect you**!
* If this is an upgrade and you are using the default PostgreSQL (`postgresql.enabled=true`), you need to pass postgresql.image.tag=9.6.18-debian-10-r7 and databaseUpgradeReady=true

## [9.6.0] - Jun 29, 2020
* Updated Artifactory version to 7.6.1 - https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.6.1
* Add tpl for external database secrets

## [9.5.5] - Jun 25, 2020
* Stop loading the Nginx stream module because it is now a core module

## [9.5.4] - Jun 25, 2020
* Notes.txt update - add --namespace parameter

## [9.5.3] - Jun 11, 2020
* Support list of custom secrets

## [9.5.2] - Jun 12, 2020
* Updated Artifactory version to 7.5.7 - https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.5.7

## [9.5.1] - Jun 8, 2020
* Readme update - configuring Artifactory with oracledb

## [9.5.0] - Jun 1, 2020
* Updated Artifactory version to 7.5.5 - https://www.jfrog.com/confluence/display/JFROG/Artifactory+Release+Notes#ArtifactoryReleaseNotes-Artifactory7.5
* Fixes bootstrap configMap permission issue
* Update postgresql tag version to `9.6.18-debian-10-r7`

## [9.4.9] - May 27, 2020
* Added Tomcat maxThreads & acceptCount

## [9.4.8] - May 25, 2020
* Fixed postgresql README `image` Parameters

## [9.4.7] - May 24, 2020
* Fixed typo in README regarding migration timeout

## [9.4.6] - May 19, 2020
* Added metadata maxOpenConnections

## [9.4.5] - May 07, 2020
* Fix `installerInfo` string format

## [9.4.4] - Apr 27, 2020
* Updated Artifactory version to 7.4.3

## [9.4.3] - Apr 26, 2020
* Change order of the customInitContainers to run before the "migration-artifactory" initContainer.

## [9.4.2] - Apr 24, 2020
* Fix `artifactory.persistence.awsS3V3.useInstanceCredentials` incorrect conditional logic
* Bump postgresql tag version to `9.6.17-debian-10-r72` in values.yaml

## [9.4.1] - Apr 16, 2020
* Custom volumes in migration init container.

## [9.4.0] - Apr 14, 2020
* Updated Artifactory version to 7.4.1

## [9.3.1] - April 13, 2020
* Update README with helm v3 commands

## [9.3.0] - April 10, 2020
* Use dependency charts from `https://charts.bitnami.com/bitnami`
* Bump postgresql chart version to `8.7.3` in requirements.yaml
* Bump postgresql tag version to `9.6.17-debian-10-r21` in values.yaml

## [9.2.9] - Apr 8, 2020
* Added recommended ingress annotation to avoid 413 errors

## [9.2.8] - Apr 8, 2020
* Moved migration scripts under `files` directory
* Support preStartCommand in migration Init container as `artifactory.migration.preStartCommand`

## [9.2.7] - Apr 6, 2020
* Fix cache size (should be 5gb instead of 50gb since volume claim is only 20gb).

## [9.2.6] - Apr 1, 2020
* Support masterKey and joinKey as secrets

## [9.2.5] - Apr 1, 2020
* Fix readme use to `-hex 32` instead of `-hex 16`

## [9.2.4] - Mar 31, 2020
* Change the way the artifactory `command:` is set so it will properly pass a SIGTERM to java

## [9.2.3] - Mar 29, 2020
* Add Nginx log options: stderr as logfile and log level

## [9.2.2] - Mar 30, 2020
* Use the same defaulting mechanism used for the artifactory version used elsewhere in the chart

## [9.2.1] - Mar 29, 2020
* Fix loggers sidecars configurations to support new file system layout and new log names

## [9.2.0] - Mar 29, 2020
* Fix broken admin user bootstrap configuration
* **Breaking change:** renamed `artifactory.accessAdmin` to `artifactory.admin`

## [9.1.5] - Mar 26, 2020
* Fix volumeClaimTemplate issue

## [9.1.4] - Mar 25, 2020
* Fix volume name used by filebeat container

## [9.1.3] - Mar 24, 2020
* Use `postgresqlExtendedConf` for setting custom PostgreSQL configuration (instead of `postgresqlConfiguration`)

## [9.1.2] - Mar 22, 2020
* Support for SSL offload in Nginx service(LoadBalancer) layer. Introduced `nginx.service.ssloffload` field with boolean type.

## [9.1.1] - Mar 23, 2020
* Moved installer info to values.yaml so it is fully customizable

## [9.1.0] - Mar 23, 2020
* Updated Artifactory version to 7.3.2

## [9.0.29] - Mar 20, 2020
* Add support for masterKey trim during 6.x to 7.x migration if 6.x masterKey is 32 hex (64 characters)

## [9.0.28] - Mar 18, 2020
* Increased Nginx proxy_buffers size

## [9.0.27] - Mar 17, 2020
* Changed all single quotes to double quotes in values files
* useInstanceCredentials variable was declared in S3 settings but not used in chart. Now it is being used.

## [9.0.26] - Mar 17, 2020
* Fix rendering of Service Account annotations

## [9.0.25] - Mar 16, 2020
* Update Artifactory readme with extra ingress annotations needed for Artifactory to be set as SSO provider

## [9.0.24] - Mar 16, 2020
* Add Unsupported message from 6.18 to 7.2.x (migration)

## [9.0.23] - Mar 12, 2020
* Fix README.md rendering issue

## [9.0.22] - Mar 11, 2020
* Upgrade Docs update

## [9.0.21] - Mar 11, 2020
* Unified charts public release

## [9.0.20] - Mar 6, 2020
* Fix path to `/artifactory_bootstrap`
* Add support for controlling the name of the ingress and allow to set more than one cname

## [9.0.19] - Mar 4, 2020
* Add support for disabling `consoleLog` in `system.yaml` file

## [9.0.18] - Feb 28, 2020
* Add support to process `valueFrom` for extraEnvironmentVariables

## [9.0.17] - Feb 26, 2020
* Fix join key secret naming

## [9.0.16] - Feb 26, 2020
* Store join key to secret

## [9.0.15] - Feb 26, 2020
* Updated Artifactory version to 7.2.1

## [9.0.10] - Feb 07, 2020
* Remove protection flag `databaseUpgradeReady` which was added to check internal postgres upgrade

## [9.0.0] - Feb 07, 2020
* Updated Artifactory version to 7.0.0

## [8.4.8] - Feb 13, 2020
* Add support for SSH authentication to Artifactory

## [8.4.7] - Feb 11, 2020
* Change Artifactory service port name to be hard-coded to `http` instead of using `{{ .Release.Name }}`

## [8.4.6] - Feb 9, 2020
* Add support for `tpl` in the `postStartCommand`

## [8.4.5] - Feb 4, 2020
* Support customisable Nginx kind

## [8.4.4] - Feb 2, 2020
* Add a comment stating that it is recommended to use an external PostgreSQL with a static password for production installations

## [8.4.3] - Jan 30, 2020
* Add the option to configure resources for the logger containers

## [8.4.2] - Jan 26, 2020
* Improve `database.user` and `database.password` logic in order to support more use cases and make the configuration less repetitive

## [8.4.1] - Jan 19, 2020
* Fix replicator port config in nginx replicator configmap

## [8.4.0] - Jan 19, 2020
* Updated Artifactory version to 6.17.0

## [8.3.6] - Jan 16, 2020
* Added example for external nginx-ingress

## [8.3.5] - Dec 30, 2019
* Fix for nginx probes failing when launched with http disabled

## [8.3.4] - Dec 24, 2019
* Better support for custom `artifactory.internalPort`

## [8.3.3] - Dec 23, 2019
* Mark empty map values with `{}`

## [8.3.2] - Dec 16, 2019
* Fix for toggling nginx service ports

## [8.3.1] - Dec 12, 2019
* Add support for toggling nginx service ports

## [8.3.0] - Dec 1, 2019
* Updated Artifactory version to 6.16.0

## [8.2.6] - Nov 28, 2019
* Add support for using existing PriorityClass

## [8.2.5] - Nov 27, 2019
* Add support for PriorityClass

## [8.2.4] - Nov 21, 2019
* Add an option to use a file system cache-fs with the file-system binarystore template

## [8.2.3] - Nov 20, 2019
* Update Artifactory Readme

## [8.2.2] - Nov 20, 2019
* Update Artfactory logo

## [8.2.1] - Nov 18, 2019
* Add the option to provide service account annotations (in order to support stuff like https://docs.aws.amazon.com/eks/latest/userguide/specify-service-account-role.html)

## [8.2.0] - Nov 18, 2019
* Updated Artifactory version to 6.15.0

## [8.1.11] - Nov 17, 2019
* Do not provide a default master key. Allow it to be auto generated by Artifactory on first startup

## [8.1.10] - Nov 17, 2019
* Fix creation of double slash in nginx artifactory configuration

## [8.1.9] - Nov 14, 2019
* Set explicit `postgresql.postgresqlPassword=""` to avoid helm v3 error

## [8.1.8] - Nov 12, 2019
* Updated Artifactory version to 6.14.1

## [8.1.7] - Nov 9, 2019
* Additional documentation for masterKey

## [8.1.6] - Nov 10, 2019
* Update PostgreSQL chart version to 7.0.1
* Use formal PostgreSQL configuration format

## [8.1.5] - Nov 8, 2019
* Add support `artifactory.service.loadBalancerSourceRanges` for whitelisting when setting `artifactory.service.type=LoadBalancer`

## [8.1.4] - Nov 6, 2019
* Add support for any type of environment variable by using `extraEnvironmentVariables` as-is

## [8.1.3] - Nov 6, 2019
* Add nodeselector support for Postgresql

## [8.1.2] - Nov 5, 2019
* Add support for the aws-s3-v3 filestore, which adds support for pod IAM roles

## [8.1.1] - Nov 4, 2019
* When using `copyOnEveryStartup`, make sure that the target base directories are created before copying the files

## [8.1.0] - Nov 3, 2019
* Updated Artifactory version to 6.14.0

## [8.0.1] - Nov 3, 2019
* Make sure the artifactory pod exits when one of the pre-start stages fail

## [8.0.0] - Oct 27, 2019
**IMPORTANT - BREAKING CHANGES!**<br>
**DOWNTIME MIGHT BE REQUIRED FOR AN UPGRADE!**
* If this is a new deployment or you already use an external database (`postgresql.enabled=false`), these changes **do not affect you**!
* If this is an upgrade and you are using the default PostgreSQL (`postgresql.enabled=true`), must use the upgrade instructions in [UPGRADE_NOTES.md](UPGRADE_NOTES.md)!
* PostgreSQL sub chart was upgraded to version `6.5.x`. This version is **not backward compatible** with the old version (`0.9.5`)!
* Note the following **PostgreSQL** Helm chart changes
  * The chart configuration has changed! See [values.yaml](values.yaml) for the new keys used
  * **PostgreSQL** is deployed as a StatefulSet
  * See [PostgreSQL helm chart](https://hub.helm.sh/charts/stable/postgresql) for all available configurations

## [7.18.3] - Oct 24, 2019
* Change the preStartCommand to support templating

## [7.18.2] - Oct 21, 2019
* Add support for setting `artifactory.labels`
* Add support for setting `nginx.labels`

## [7.18.1] - Oct 10, 2019
* Updated Artifactory version to 6.13.1

## [7.18.0] - Oct 7, 2019
* Updated Artifactory version to 6.13.0

## [7.17.5] - Sep 24, 2019
* Option to skip wait-for-db init container with '--set waitForDatabase=false'

## [7.17.4] - Sep 11, 2019
* Updated Artifactory version to 6.12.2

## [7.17.3] - Sep 9, 2019
* Updated Artifactory version to 6.12.1

## [7.17.2] - Aug 22, 2019
* Fix the nginx server_name directive used with ingress.hosts

## [7.17.1] - Aug 21, 2019
* Enable the Artifactory container's liveness and readiness probes

## [7.17.0] - Aug 21, 2019
* Updated Artifactory version to 6.12.0

## [7.16.11] - Aug 14, 2019
* Updated Artifactory version to 6.11.6

## [7.16.10] - Aug 11, 2019
* Fix Ingress routing and add an example

## [7.16.9] - Aug 5, 2019
* Do not mount `access/etc/bootstrap.creds` unless user specifies a custom password or secret (Access already generates a random password if not provided one)
* If custom `bootstrap.creds` is provided (using keys or custom secret), prepare it with an init container so the temp file does not persist

## [7.16.8] - Aug 4, 2019
* Improve binarystore config
    1. Convert to a secret
    2. Move config to values.yaml
    3. Support an external secret

## [7.16.7] - Jul 29, 2019
* Don't create the nginx configmaps when nginx.enabled is false

## [7.16.6] - Jul 24, 2019
* Simplify nginx setup and shorten initial wait for probes

## [7.16.5] - Jul 22, 2019
* Change Ingress API to be compatible with recent kubernetes versions

## [7.16.4] - Jul 22, 2019
* Updated Artifactory version to 6.11.3

## [7.16.3] - Jul 11, 2019
* Add ingress.hosts to the Nginx server_name directive when ingress is enabled to help with Docker repository sub domain configuration

## [7.16.2] - Jul 3, 2019
* Fix values key in reverse proxy example

## [7.16.1] - Jul 1, 2019
* Updated Artifactory version to 6.11.1

## [7.16.0] - Jun 27, 2019
* Update Artifactory version to 6.11 and add restart to Artifactory when bootstrap.creds file has been modified

## [7.15.8] - Jun 27, 2019
* Add the option for changing nginx config using values.yaml and remove outdated reverse proxy documentation

## [7.15.6] - Jun 24, 2019
* Update chart maintainers

## [7.15.5] - Jun 24, 2019
* Change Nginx to point to the artifactory externalPort

## [7.15.4] - Jun 23, 2019
* Add the option to provide an IP for the access-admin endpoints

## [7.15.3] - Jun 23, 2019
* Add values files for small, medium and large installations

## [7.15.2] - Jun 20, 2019
* Add missing terminationGracePeriodSeconds to values.yaml

## [7.15.1] - Jun 19, 2019
* Updated Artifactory version to 6.10.4

## [7.15.0] - Jun 17, 2019
* Use configmaps for nginx configuration and remove nginx postStart command

## [7.14.8] - Jun 18, 2019
* Add the option to provide additional ingress rules

## [7.14.7] - Jun 14, 2019
* Updated readme with improved external database setup example

## [7.14.6] - Jun 11, 2019
* Updated Artifactory version to 6.10.3
* Updated installer-info template

## [7.14.5] - Jun 6, 2019
* Updated Google Cloud Storage API URL and https settings

## [7.14.4] - Jun 5, 2019
* Delete the db.properties file on Artifactory startup

## [7.14.3] - Jun 3, 2019
* Updated Artifactory version to 6.10.2

## [7.14.2] - May 21, 2019
* Updated Artifactory version to 6.10.1

## [7.14.1] - May 19, 2019
* Fix missing logger image tag

## [7.14.0] - May 7, 2019
* Updated Artifactory version to 6.10.0

## [7.13.21] - May 5, 2019
* Add support for setting `artifactory.async.corePoolSize`

## [7.13.20] - May 2, 2019
* Remove unused property `artifactory.releasebundle.feature.enabled`

## [7.13.19] - May 1, 2019
* Fix indentation issue with the replicator system property

## [7.13.18] - Apr 30, 2019
* Add support for JMX monitoring

## [7.13.17] - Apr 25, 2019
* Added support for `cacheProviderDir`

## [7.13.16] - Apr 18, 2019
* Changing API StatefulSet version to `v1` and permission fix for custom `artifactory.conf` for Nginx

## [7.13.15] - Apr 16, 2019
* Updated documentation for Reverse Proxy Configuration

## [7.13.14] - Apr 15, 2019
* Added support for `customVolumeMounts`

## [7.13.13] - Aprl 12, 2019
* Added support for `bucketExists` flag for googleStorage

## [7.13.12] - Apr 11, 2019
* Replace `curl` examples with `wget` due to the new base image

## [7.13.11] - Aprl 07, 2019
* Add support for providing the Artifactory license as a parameter

## [7.13.10] - Apr 10, 2019
* Updated Artifactory version to 6.9.1

## [7.13.9] - Aprl 04, 2019
* Add support for templated extraEnvironmentVariables

## [7.13.8] - Aprl 07, 2019
* Change network policy API group

## [7.13.7] - Aprl 04, 2019
* Bugfix for userPluginSecrets

## [7.13.6] - Apr 4, 2019
* Add information about upgrading Artifactory with auto-generated postgres password

## [7.13.5] - Aprl 03, 2019
* Added installer info

## [7.13.4] - Aprl 03, 2019
* Allow secret names for user plugins to contain template language

## [7.13.3] - Apr 02, 2019
* Allow NetworkPolicy configurations (defaults to allow all)

## [7.13.2] - Aprl 01, 2019
* Add support for user plugin secret

## [7.13.1] - Mar 27, 2019
* Add the option to copy a list of files to ARTIFACTORY_HOME on startup

## [7.13.0] - Mar 26, 2019
* Updated Artifactory version to 6.9.0

## [7.12.18] - Mar 25, 2019
* Add CI tests for persistence, ingress support and nginx

## [7.12.17] - Mar 22, 2019
* Add the option to change the default access-admin password

## [7.12.16] - Mar 22, 2019
* Added support for `<artifactory|nginx>.<readiness|liveness>Probe.path` to customise the paths used for health probes

## [7.12.15] - Mar 21, 2019
* Added support for `artifactory.customSidecarContainers` to create custom sidecar containers
* Added support for `artifactory.customVolumes` to create custom volumes

## [7.12.14] - Mar 21, 2019
* Make ingress path configurable

## [7.12.13] - Mar 19, 2019
* Move the copy of bootstrap config from postStart to preStart

## [7.12.12] - Mar 19, 2019
* Fix existingClaim example

## [7.12.11] - Mar 18, 2019
* Add information about nginx persistence

## [7.12.10] - Mar 15, 2019
* Wait for nginx configuration file before using it

## [7.12.9] - Mar 15, 2019
* Revert securityContext changes since they were causing issues

## [7.12.8] - Mar 15, 2019
* Fix issue #247 (init container failing to run)

## [7.12.7] - Mar 14, 2019
* Updated Artifactory version to 6.8.7
* Add support for Artifactory-CE for C++

## [7.12.6] - Mar 13, 2019
* Move securityContext to container level

## [7.12.5] - Mar 11, 2019
* Updated Artifactory version to 6.8.6

## [7.12.4] - Mar 8, 2019
* Fix existingClaim option

## [7.12.3] - Mar 5, 2019
* Updated Artifactory version to 6.8.4

## [7.12.2] - Mar 4, 2019
* Add support for catalina logs sidecars

## [7.12.1] - Feb 27, 2019
* Updated Artifactory version to 6.8.3

## [7.12.0] - Feb 25, 2019
* Add nginx support for tail sidecars

## [7.11.1] - Feb 20, 2019
* Added support for enterprise storage

## [7.10.2] - Feb 19, 2019
* Updated Artifactory version to 6.8.2

## [7.10.1] - Feb 17, 2019
* Updated Artifactory version to 6.8.1
* Add example of `SERVER_XML_EXTRA_CONNECTOR` usage

## [7.10.0] - Feb 15, 2019
* Updated Artifactory version to 6.8.0

## [7.9.6] - Feb 13, 2019
* Updated Artifactory version to 6.7.3

## [7.9.5] - Feb 12, 2019
*  Add support for tail sidecars to view logs from k8s api

## [7.9.4] - Feb 6, 2019
* Fix support for customizing statefulset `terminationGracePeriodSeconds`

## [7.9.3] - Feb 5, 2019
* Add instructions on how to deploy Artifactory with embedded Derby database

## [7.9.2] - Feb 5, 2019
* Add support for customizing statefulset `terminationGracePeriodSeconds`

## [7.9.1] - Feb 3, 2019
* Updated Artifactory version to 6.7.2

## [7.9.0] - Jan 23, 2019
* Updated Artifactory version to 6.7.0

## [7.8.9] - Jan 22, 2019
* Added support for `artifactory.customInitContainers` to create custom init containers

## [7.8.8] - Jan 17, 2019
* Added support of values ingress.labels

## [7.8.7] - Jan 16, 2019
* Mount replicator.yaml (config) directly to /replicator_extra_conf

## [7.8.6] - Jan 13, 2019
* Fix documentation about nginx group id

## [7.8.5] - Jan 13, 2019
* Updated Artifactory version to 6.6.5

## [7.8.4] - Jan 8, 2019
* Make artifactory.replicator.publicUrl required when the replicator is enabled

## [7.8.3] - Jan 1, 2019
* Updated Artifactory version to 6.6.3
* Add support for `artifactory.extraEnvironmentVariables` to pass more environment variables to Artifactory

## [7.8.2] - Dec 28, 2018
* Fix location `replicator.yaml` is copied to

## [7.8.1] - Dec 27, 2018
* Updated Artifactory version to 6.6.1

## [7.8.0] - Dec 20, 2018
* Updated Artifactory version to 6.6.0

## [7.7.13] - Dec 17, 2018
* Updated Artifactory version to 6.5.13

## [7.7.12] - Dec 12, 2018
* Fix documentation about Artifactory license setup using secret

## [7.7.11] - Dec 10, 2018
* Fix issue when using existing claim

## [7.7.10] - Dec 5, 2018
* Remove Distribution certificates creation.

## [7.7.9] - Nov 30, 2018
* Updated Artifactory version to 6.5.9

## [7.7.8] - Nov 29, 2018
* Updated postgresql version to 9.6.11

## [7.7.7] - Nov 27, 2018
* Updated Artifactory version to 6.5.8

## [7.7.6] - Nov 19, 2018
* Added support for configMap to use custom Reverse Proxy Configuration with Nginx

## [7.7.5] - Nov 14, 2018
* Fix location of `nodeSelector`, `affinity` and `tolerations`

## [7.7.4] - Nov 14, 2018
* Updated Artifactory version to 6.5.3

## [7.7.3] - Nov 12, 2018
* Support artifactory.preStartCommand for running command before entrypoint starts

## [7.7.2] - Nov 7, 2018
* Support database.url parameter (DB_URL)

## [7.7.1] - Oct 29, 2018
* Change probes port to 8040 (so they will not be blocked when all tomcat threads on 8081 are exhausted)

## [7.7.0] - Oct 28, 2018
* Update postgresql chart to version 0.9.5 to be able and use `postgresConfig` options

## [7.6.8] - Oct 23, 2018
* Fix providing external secret for database credentials

## [7.6.7] - Oct 23, 2018
* Allow user to configure externalTrafficPolicy for Loadbalancer

## [7.6.6] - Oct 22, 2018
* Updated ingress annotation support (with examples) to support docker registry v2

## [7.6.5] - Oct 21, 2018
* Updated Artifactory version to 6.5.2

## [7.6.4] - Oct 19, 2018
* Allow providing pre-existing secret containing master key
* Allow arbitrary annotations on primary and member node pods
* Enforce size limits when using local storage with `emptyDir`
* Allow providing pre-existing secrets containing external database credentials

## [7.6.3] - Oct 18, 2018
* Updated Artifactory version to 6.5.1

## [7.6.2] - Oct 17, 2018
* Add Apache 2.0 license

## [7.6.1] - Oct 11, 2018
* Supports master-key in the secrets and stateful-set
* Allows ingress default `backend` to be enabled or disabled (defaults to enabled)

## [7.6.0] - Oct 11, 2018
* Updated Artifactory version to 6.5.0

## [7.5.4] - Oct 9, 2018
* Quote ingress hosts to support wildcard names

## [7.5.3] - Oct 4, 2018
* Add PostgreSQL resources template

## [7.5.2] - Oct 2, 2018
* Add `helm repo add jfrog https://charts.jfrog.io` to README

## [7.5.1] - Oct 2, 2018
* Set Artifactory to 6.4.1

## [7.5.0] - Sep 27, 2018
* Set Artifactory to 6.4.0

## [7.4.3] - Sep 26, 2018
* Add ci/test-values.yaml

## [7.4.2] - Sep 2, 2018
* Updated Artifactory version to 6.3.2
* Removed unused PVC

## [7.4.0] - Aug 22, 2018
* Added support to run as non root
* Updated Artifactory version to 6.2.0

## [7.3.0] - Aug 22, 2018
* Enabled RBAC Support
* Added support for PostStartCommand (To download Database JDBC connector)
* Increased postgresql max_connections
* Added support for `nginx.conf` ConfigMap
* Updated Artifactory version to 6.1.0
